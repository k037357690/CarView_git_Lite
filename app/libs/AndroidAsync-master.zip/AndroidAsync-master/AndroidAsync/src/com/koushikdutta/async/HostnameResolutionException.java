package com.koushikdutta.async;

public class HostnameResolutionException extends Exception {
    public HostnameResolutionException(String message) {
        super(message);
    }
}
