package com.koushikdutta.async.http;

public class WebSocketHandshakeException extends Exception {
    public WebSocketHandshakeException(String message) {
        super(message);
    }
}
