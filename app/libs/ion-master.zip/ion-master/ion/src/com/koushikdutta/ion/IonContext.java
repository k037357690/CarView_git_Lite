package com.koushikdutta.ion;

import android.content.Context;

/**
 * Created by koush on 7/2/17.
 */

public interface IonContext {
    String isAlive();
    Context getContext();
}
