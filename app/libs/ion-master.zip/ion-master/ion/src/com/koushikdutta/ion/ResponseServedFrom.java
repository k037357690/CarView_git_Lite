package com.koushikdutta.ion;

/**
 * Created by koush on 3/7/15.
 */
public enum ResponseServedFrom {
    LOADED_FROM_MEMORY,
    LOADED_FROM_CACHE,
    LOADED_FROM_CONDITIONAL_CACHE,
    LOADED_FROM_NETWORK,
}
