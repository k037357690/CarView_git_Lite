package com.koushikdutta.ion;

/**
 * Created by koush on 6/30/13.
 */
public interface HeadersCallback {
    public void onHeaders(HeadersResponse headers);
}
