package com.koushikdutta.ion.loader;

import com.koushikdutta.async.DataEmitter;
import com.koushikdutta.async.future.SimpleFuture;

final class InputStreamDataEmitterFuture extends SimpleFuture<DataEmitter> {
}
