package com.koushikdutta.ion;

enum ScaleMode {
    FitXY,
    CenterCrop,
    FitCenter,
    CenterInside,
}