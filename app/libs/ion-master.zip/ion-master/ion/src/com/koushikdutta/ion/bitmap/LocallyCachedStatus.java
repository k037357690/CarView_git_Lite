package com.koushikdutta.ion.bitmap;

/**
 * Created by koush on 6/20/14.
 */
public enum LocallyCachedStatus {
    CACHED,
    NOT_CACHED,
    MAYBE_CACHED
}
