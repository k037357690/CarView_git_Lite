package com.koushikdutta.ion;

/**
 * Created by koush on 1/18/14.
 */
public class LoadBitmapBase extends BitmapCallback {
    public LoadBitmapBase(Ion ion, String key, boolean put)  {
        super(ion, key, put);
    }
}
